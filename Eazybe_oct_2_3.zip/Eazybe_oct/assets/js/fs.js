

<div class=noteRem1>
<div class=noteRem2>
<h6 class=noteText style=padding:8px>Add a note to Remember and followupdate for this contact or group in the text field below and press Enter</h6>
<div>
<input id=noteInfo name=notesName placeholder='Note To Remember..'autocomplete=off />
<input id=followupDate name=followup-date placeholder='Next FollowupDate'type=date/>
<div style='display: flex; align-items: center;'>
<svg class='MuiSvgIcon-root-2199 _1ijF1D651fhcsls9paFVg5' focusable='false' viewBox='0 0 24 24' aria-hidden='true' style='cursor: pointer;'>
<path d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z'></path>
</svg>
</div>
</div>

 </div>
 </div>;

<svg class='MuiSvgIcon-root-2955 _1ijF1D651fhcsls9paFVg5' focusable='false' viewBox='0 0 24 24' aria-hidden='true' style='cursor: pointer;'>
<path d='M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z'>
</path>
</svg>